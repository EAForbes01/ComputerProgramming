
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

//Ethan Forbes
//25/SU ITSE 1302-7P1 Computer Programming
//07.31.25
//I2A Grand Melee




int main() {

	//Food Constants

	const float Slammin_Steak_Cost = 11.00f;
	const float Righteous_Ribs_Cost = 12.32f;
	const float Bodacious_Brussel_Sprouts_Cost = 9.75f;
	const float Fiery_Fajitas_Cost = 13.56f;
	const float Smokin_Salmon_Cost = 17.83f;
	const float A_Single_Chicken_Leg_Cost = 14.76f;
	const float Two_Single_Chicken_Legs_Cost = 3.00;

	//Tax Rate

	const float Tax_Rate = 0.0825;

	// Quantities

	int qtySlammin_Steak;
	int qtyRighteous_Ribs;
	int qtyBodacious_Brussel_Sprouts;
	int qtyFiery_Fajitas;
	int qtySmokin_Salmon;
	int qtyA_Single_Chicken_Leg;
	int qtyTwo_Single_Chicken_Legs;

	//Individual totals

	float Slammin_SteakTotal;
	float Righteous_RibsTotal;
	float Bodacious_Brussel_SproutsTotal;
	float Fiery_FajitasTotal;
	float Smokin_SalmonTotal;
	float A_Single_Chicken_LegTotal;
	float Two_Single_Chicken_LegsTotal;

	//sub, tax, and grand total

	float subtotal;
	float taxAmount;
	float grandTotal;

	//QTY Prompt 

	printf("Enter quantity for Slammin Steak: ");
	scanf("%d", &qtySlammin_Steak);
		
	printf("Enter quantity for Righteous Ribs: ");
	scanf("%d", &qtyRighteous_Ribs);

	printf("Enter quantity for Bodacious Brussel Sprouts: ");
	scanf("%d", &qtyBodacious_Brussel_Sprouts);

	printf("Enter quantity for Fiery Fajitas: ");
	scanf("%d", &qtyFiery_Fajitas);

	printf("Enter quantity for Smokin Salmon: ");
	scanf("%d", &qtySmokin_Salmon);

	printf("Enter quantity for A Single Chicken Leg: ");
	scanf("%d", &qtyA_Single_Chicken_Leg);

	printf("Enter quantity for Two Single Chicken Legs: ");
	scanf("%d", &qtyTwo_Single_Chicken_Legs); 


	// Line totals 

	Slammin_SteakTotal = qtySlammin_Steak * Slammin_Steak_Cost;
	Righteous_RibsTotal = qtyRighteous_Ribs * Righteous_Ribs_Cost;
	Bodacious_Brussel_SproutsTotal = qtyBodacious_Brussel_Sprouts * Bodacious_Brussel_Sprouts_Cost;
	Fiery_FajitasTotal = qtyFiery_Fajitas * Fiery_Fajitas_Cost;
	Smokin_SalmonTotal = qtySmokin_Salmon * Smokin_Salmon_Cost;
	A_Single_Chicken_LegTotal = qtyA_Single_Chicken_Leg * A_Single_Chicken_Leg_Cost;
	Two_Single_Chicken_LegsTotal = qtyTwo_Single_Chicken_Legs * Two_Single_Chicken_Legs_Cost;

	// sub total

	subtotal = Slammin_SteakTotal + Righteous_RibsTotal + Bodacious_Brussel_SproutsTotal
		+ Fiery_FajitasTotal + Smokin_SalmonTotal + A_Single_Chicken_LegTotal + Two_Single_Chicken_LegsTotal;

	//tax

	taxAmount = subtotal * Tax_Rate;

	// Grand Total

	printf("\nORDER SUMMARY:\n");

	printf("Slammin_Steak: %d x $%.2f = $%.2f\n", qtySlammin_Steak, Slammin_Steak_Cost, Slammin_SteakTotal);
	printf("Righteous_Ribs: %d x $%.2f = $%.2f\n", qtyRighteous_Ribs, Righteous_Ribs_Cost, Righteous_RibsTotal);
	printf("Bodacious_Brussel_Sprouts: %d x $%.2f = $%.2f\n", qtyBodacious_Brussel_Sprouts, Bodacious_Brussel_Sprouts_Cost, Bodacious_Brussel_SproutsTotal);
	printf("Fiery_Fajitas: %d x $%.2f = $%.2f\n", qtyFiery_Fajitas, Fiery_Fajitas_Cost, Fiery_FajitasTotal);
	printf("Smokin_Salmon: %d x $%.2f = $%.2f\n", qtySmokin_Salmon, Smokin_Salmon_Cost, Smokin_SalmonTotal);
	printf("A_Single_Chicken_Leg: %d x $%.2f = $%.2f\n", qtyA_Single_Chicken_Leg, A_Single_Chicken_Leg_Cost, A_Single_Chicken_LegTotal);
	printf("Two_Single_Chicken_Legs: %d x $%.2f = $%.2f\n", qtyTwo_Single_Chicken_Legs, Two_Single_Chicken_Legs_Cost, Two_Single_Chicken_LegsTotal);

	printf("\nSubtotal: $%.2f\n", subtotal);
	printf("Tax (8.25%%): $%.2f\n", taxAmount);

	// Grand Total Math
	grandTotal = subtotal + taxAmount;

	printf("Grand Total: $%.2f\n", grandTotal);

	return 0;

}