
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

//Ethan Forbes
//25/SU ITSE 1302-7P1 Computer Programming
//07.31.25
//I2A Grand Melee




int main() {

	//Food Constants

	const float Fish_Shrimp_Cost = 11.00f;
	const float Steak_Slammer_Cost = 12.32f;
	const float Ballin_Boudin_Cost = 9.75f;
	const float Flamin_Fajitas_Cost = 13.56f;
	const float Spicy_Shellfish_Cost = 17.83f;
	const float Real_Gouda_Cost = 14.76f;
	//Cause its chilly lol. 
	const float Cold_Chili_Cost = 3.00;

	//Tax Rate

	const float Tax_Rate = 0.0825;

	// Quantities

	int qtyFish_Shrimp;
	int qtySteak_Slammer;
	int qtyBallin_Boudin;
	int qtyFlamin_Fajitas;
	int qtySpicy_Shellfish;
	int qtyReal_Gouda;
	int qtyCold_Chili;

	//Individual totals

	float Fish_ShrimpTotal;
	float Steak_SlammerTotal;
	float Ballin_BoudinTotal;
	float Flamin_FajitasTotal;
	float Spicy_ShellfishTotal;
	float Real_GoudaTotal;
	float Cold_ChiliTotal;

	//sub, tax, and grand total

	float subtotal;
	float taxAmount;
	float grandTotal;

	//QTY Prompt 

	printf("Enter quantity for Fish and Shrimp: ");
	scanf("%d", &qtyFish_Shrimp);
		
	printf("Enter quantity for Steak Slammer: ");
	scanf("%d", &qtySteak_Slammer);

	printf("Enter quantity for Ballin Boudin: ");
	scanf("%d", &qtyBallin_Boudin);

	printf("Enter quantity for Flamin Fajitas: ");
	scanf("%d", &qtyFlamin_Fajitas);

	printf("Enter quantity for Spicy Shellfish: ");
	scanf("%d", &qtySpicy_Shellfish);

	printf("Enter quantity for Real_Gouda: ");
	scanf("%d", &qtyReal_Gouda);

	printf("Enter quantity for Cold Chili: ");
	scanf("%d", &qtyCold_Chili); 


	// Line totals 

	Fish_ShrimpTotal = qtyFish_Shrimp * Fish_Shrimp_Cost;
	Steak_SlammerTotal = qtySteak_Slammer * Steak_Slammer_Cost;
	Ballin_BoudinTotal = qtyBallin_Boudin * Ballin_Boudin_Cost;
	Flamin_FajitasTotal = qtyFlamin_Fajitas * Flamin_Fajitas_Cost;
	Spicy_ShellfishTotal = qtySpicy_Shellfish * Spicy_Shellfish_Cost;
	Real_GoudaTotal = qtyReal_Gouda * Real_Gouda_Cost;
	Cold_ChiliTotal = qtyCold_Chili * Cold_Chili_Cost;

	// sub total

	subtotal = Fish_ShrimpTotal + Steak_SlammerTotal + Ballin_BoudinTotal
		+ Flamin_FajitasTotal + Spicy_ShellfishTotal + Real_GoudaTotal + Cold_ChiliTotal;

	//tax

	taxAmount = subtotal * Tax_Rate;

	// Grand Total

	printf("\nORDER SUMMARY:\n");

	printf("Fish and Shrimp: %d x $%.2f = $%.2f\n", qtyFish_Shrimp, Fish_Shrimp_Cost, Fish_ShrimpTotal);
	printf("Steak Slammer: %d x $%.2f = $%.2f\n", qtySteak_Slammer, Steak_Slammer_Cost, Steak_SlammerTotal);
	printf("Ballin Boudin: %d x $%.2f = $%.2f\n", qtyBallin_Boudin, Ballin_Boudin_Cost, Ballin_BoudinTotal);
	printf("Flamin Fajitas: %d x $%.2f = $%.2f\n", qtyFlamin_Fajitas, Flamin_Fajitas_Cost, Flamin_FajitasTotal);
	printf("Spicy Shellfish: %d x $%.2f = $%.2f\n", qtySpicy_Shellfish, Spicy_Shellfish_Cost, Spicy_ShellfishTotal);
	printf("Real Gouda: %d x $%.2f = $%.2f\n", qtyReal_Gouda, Real_Gouda_Cost, Real_GoudaTotal);
	printf("Cold Chili: %d x $%.2f = $%.2f\n", qtyCold_Chili, Cold_Chili_Cost, Cold_ChiliTotal);

	printf("\nSubtotal: $%.2f\n", subtotal);
	printf("Tax (8.25%%): $%.2f\n", taxAmount);

	// Grand Total Math
	grandTotal = subtotal + taxAmount;

	printf("Grand Total: $%.2f\n", grandTotal);

	return 0;

}